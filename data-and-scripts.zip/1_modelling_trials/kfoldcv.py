import tensorflow as tf
import wandb
from wandb.keras import WandbMetricsLogger

def trainmodelCV(model,xdata,ydata,args):
    wandb.init(config={"bs": 12},project='msc-Thesis')
    print("Fit model on training data")
    NUMBER_EPOCHS = args['nepoch']
    filepath=args['ckpt']
    BATCH_SIZE=args['batchsize']
    # validation_split=args['valsplit']
    
    model_checkpoint_callback=tf.keras.callbacks.ModelCheckpoint(
        filepath,
        monitor="val_loss",
        verbose=1,
        save_best_only=True,
        save_weights_only=False,
        mode="min",
        save_freq="epoch",
        options=None
    )
    
    hist = model.fit(x=xdata,
                     y=ydata,
                     epochs=NUMBER_EPOCHS,
                     batch_size=BATCH_SIZE,
                    #  validation_split=validation_split,
                    # validation_data=(x_val,y_val),
                     verbose=1, 
                    #  callbacks=[model_checkpoint_callback]
                     callbacks=[model_checkpoint_callback, WandbMetricsLogger(log_freq='epoch')]
                    )
    return hist