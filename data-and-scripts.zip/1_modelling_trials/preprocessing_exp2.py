import numpy as np
from scipy.stats import zscore
import pandas as pd 

def minMaxScaler(input): 
    '''input is an array, output is scaled values'''
    min = np.min(input)
    max = np.max(input)
    new = []
    for i in input: 
        out = (i-min)/(max-min)
        new.append(out)
    return np.array(new)

def diffRainfallprep(inputDf):
    '''
    Function that takes an input dataframe with only daily rainfall values eg. day1_max, day2_max...
    and outputs a dataframe containing the difference between each time step
    for the first timestep, difference is automatically set to 0 
    '''

    # initiate new df
    diff_df = pd.DataFrame()

    # iterate over the columns of the original DataFrame
    for i in range(1, len(inputDf.columns)):
        if i == 1: 
            diff_df[f'diff_{1}'] = 0

        # calculate the difference between the ith column and the previous column
        diff = inputDf.iloc[:, i] - inputDf.iloc[:, i-1]
        # add the difference as a new column in the diff_df DataFrame
        diff_df[f'diff_{i+1}'] = diff

        diff_df['diff_1'].fillna(value=0,inplace=True)

    # # display the resulting DataFrame
    return diff_df

### all these scripts are applicable for modelling with cumulative rainfall, and new normalization method

def rainfallMatrix_4(maxDf, sumDf, cumDf, diffDf): 
    '''
    input: dataframes only containing the rainfall
    returns out array of: [[[max1_1,sum1_1,cum1_1, diff1_1], [max1_2,sum1_2,cum1_2, diff1_2 ]...[max1_30,sum1_30,cum1_30,diff1_30 ]],
                            [max2_1,sum2_1,cum2_1,diff2_1], [max2_2,sum2_2,cum2_2,diff2_2]...[max2_30,sum2_30,cum2_30,diff2_30],
                            ....
                            [maxlast_1,sumlast_1,cumlast_1,difflast_1], [maxlast_2,sumlast_2,cumlast_2,difflast_2]...[maxlast_30,sumlast_30,cumlast_30, difflast_30]]] 
    it's essentially 3 layers of list
    1st array: holds all rows 
    2nd array: holds each row (i.e. contains 30 of 3rd array)
    3rd array layer: holds max,sum,cum,diff of each day whereby each 'row' = one landslide event
    '''
    maxDfLen = len(maxDf)
    sumDfLen = len(sumDf)
    cumDfLen = len(cumDf)
    diffDfLen = len(diffDf)

    if maxDfLen != sumDfLen: 
        print("max df length doesn't match sum ")
    
    elif maxDfLen != cumDfLen: 
        print("max df length doesn't match cumulative")
    
    elif sumDfLen != cumDfLen: 
        print("sum df length doesn't match cumulative")
    
    elif sumDfLen != diffDfLen:
        print("sum df length doesn't match difference")

    elif maxDfLen != diffDfLen:
        print("max df length doesn't match difference")
    
    elif cumDfLen != diffDfLen:
        print("cumulative df length doesn't match difference")
    
    timeSeriesLength = len(maxDf.columns)

    mainMatrix = []
    occurrenceMatrix = []
    dayMatrix = []

    for i in np.arange(0, maxDfLen, 1):
        for j in np.arange(0, timeSeriesLength, 1): # note the format is [row,col]
            dayMatrix = [maxDf.iloc[i,j], sumDf.iloc[i,j], cumDf.iloc[i,j], diffDf.iloc[i,j]]
            occurrenceMatrix.append(dayMatrix)
            dayMatrix = []
        mainMatrix.append(occurrenceMatrix)
        occurrenceMatrix = []
    
    return np.array(mainMatrix, dtype=np.float64)

def rainfallMatrix(maxDf, sumDf, cumDf): 
    '''
    input: dataframes only containing the rainfall
    returns out array of: [[[max1_1,sum1_1,cum1_1], [max1_2,sum1_2,cum_12]...[max1_30,sum1_30,cum1_30]],
                            [max2_1,sum2_1,cum2_1], [max2_2,sum2_2,cum2_2]...[max2_30,sum2_30,cum2_30],
                            ....
                            [maxlast_1,sumlast_1,cumlast_1], [maxlast_2,sumlast_2,cumlast_2]...[maxlast_30,sumlast_30,cumlast_30]]] 
    it's essentially 3 layers of list
    1st array: holds all rows 
    2nd array: holds each row (i.e. contains 30 of 3rd array)
    3rd array layer: holds max,sum,cum of each day whereby each 'row' = one landslide event
    '''
    maxDfLen = len(maxDf)
    sumDfLen = len(sumDf)
    cumDfLen = len(cumDf)
#     if maxDfLen != sumDfLen: 
#         return print("max df length doesn't match sum ")
    
#     if maxDfLen != cumDfLen: 
#         return print("max df length doesn't match cumulative")
    
#     if sumDfLen != cumDfLen: 
#         return print("sum df length doesn't match cumulative")
    
    timeSeriesLength = len(maxDf.columns)

    mainMatrix = []
    occurrenceMatrix = []
    dayMatrix = []

    for i in np.arange(0, maxDfLen, 1):
        for j in np.arange(0, timeSeriesLength, 1): # note the format is [row,col]
            dayMatrix = [maxDf.iloc[i,j], sumDf.iloc[i,j], cumDf.iloc[i,j]]
            occurrenceMatrix.append(dayMatrix)
            dayMatrix = []
        mainMatrix.append(occurrenceMatrix)
        occurrenceMatrix = []
    
    
    if len(mainMatrix) != len(mainMatrix): 
        return print("something fucked up")
    else: 
        return np.array(mainMatrix, dtype=np.float64)
    
def cumRainfall(inputDf, startCol:int, endCol:int, name:str): 
    '''
    Function to create cumulative rainfall columns for each day
    Inputs: dataframe containing all the variables you want 
            Start col: column index of day1_sum
            endCol: column index of day30_sum
            name: what rainfall parameter it is eg. max, sum
    Output: dataframe containing sum of rainfall, max of rainfall and cumulative sum rainfall appended 
    '''
    sumDf = inputDf.iloc[:,np.arange(startCol,endCol +1,2)]
    # create new dataframe containing cumulative rainfall values 
    cumSumDf = sumDf.copy()

    for i in np.arange(len(sumDf)):
        for j in np.arange(len(sumDf.columns)):
            if j != 0: 
                cumSumDf.iloc[i,j] = cumSumDf.iloc[i,j-1] + cumSumDf.iloc[i,j]         

    # rename column names 
    sum_orignames = []
    for col in cumSumDf.columns:
        sum_orignames.append(col)

    numb = []
    for i in np.arange(1,31,1):
        numb.append(i)

    dicNames = {}
    counter = 0 
    for j in sum_orignames: 
        newname = 'cum' + name + '_' + str(numb[counter])
        dicNames[j] = newname
        counter+=1

    cumSumDf.rename(columns=dicNames, inplace=True)
    # print("Columns have been renamed successfully as follows: \n:")
    # for entry, key in dicNames.items(): 
    #     print("Original name was ", entry, " and the new name is ", key)
    
    return cumSumDf, sumDf

def catPrep(inputDf, listOfCatCols: list):
    '''
    Function to prepare categorical covariates to be analysis ready through one hot encoding
    Inputs: 
        inputDf: input dataframe 
        listOfCatCols: list storing names of categorical columns in the input dataframe
    Output: 
        original dataframe with the categorical column being one-hot-encoded 
    '''
    
    print("You have one-hot encoded ", len(listOfCatCols), " categorical variables. These are: \n" )
    for i in listOfCatCols: 
        print(i, "\n")

    newDf = pd.get_dummies(data = inputDf, columns = listOfCatCols)
    in_array_stat = newDf.to_numpy()
    return in_array_stat, newDf


def normCols(inputDf, catCols: list):
    '''
    Function to normalize numeric columns using Z score ###
    inputDf: input dataframe, catCols: list indicating names of categorical columns
    '''
    
    normDf = inputDf.copy()
    for i in catCols: 
        normDf = normDf.astype({i: str})
    # rainfallNorm["id"] = rainfallNorm.index + 1
    # rainfallNormBefore = rainfallNorm.copy()
    print(normDf.dtypes, "\n")
    numeric_cols = normDf.select_dtypes(include=[np.float64]).columns
    print(numeric_cols)
    normDf[numeric_cols] = normDf[numeric_cols].apply(zscore)
    normDf.head(10) 
    return normDf


def makeRainfallDf(inputDf, lsCol: int, startInd: int, endInd: int ):
    '''
    Function that takes in the indices of the columns you'd like to keep, and makes it into a new dataframe
    '''

    wantedCol = [lsCol] # specify the index of landslide column in there 
    for i in range(startInd, endInd):
        wantedCol.append(i)

    rainfallDf = inputDf.iloc[:, wantedCol]

    if isinstance(rainfallDf, pd.DataFrame):
        print("dataframe")

    return rainfallDf

'''
Function that takes the input of a dataframe containing only landslides, as well as rainfall values (max and sum)
returns out the rainfall values into the desired format: [[[max1,sum1], [max2,sum2]...]], whereby each 'row' = one landslide event
'''

def dataMatrix(inputDf): 
    xData = []
    subList = [] # each landslide occurrence has one sublist i.e. row 
    tempList = [] # [max, sum] per day 
    count = 0
  
    yData = inputDf['landslide'] # target variable, in this case landslides. extract it first, then drop it 
    inputDf = inputDf.drop('landslide',axis=1)
    
    nRows = len(inputDf)
    nCol = len(inputDf.axes[1])
    print("The number of rows and columns are ", nRows, " and ", nCol, "respectively")

    for row in range(nRows):
        # print(inputDf.iloc[row,:])
        for col in range(nCol): 
            if count <= 1: 
                tempList.append(inputDf.iloc[row,col])
                count += 1 
                # print("temp list in the if :", tempList, "\n")
                # print(count)
            else:
                # print("templist in the else: ", tempList, "\n")
                # sublist = [] 
                if tempList != []:
                    subList.append(tempList) 
                    # print("sublist appended: ", subList, "\n")
                    tempList = []
                    tempList.append(inputDf.iloc[row,col])
                    count = 1  
                    # print("templist in the else, newly refreshed: ", tempList, "\n")
                else:
                    tempList.append(inputDf.iloc[row,col])

        subList.append(tempList)
        xData.append(subList)
        # print("appended xData ", xData, "\n") 
        subList = []
        tempList = []
        count = 0

    if len(xData) == len(inputDf):
        print("the number of lists corresponds, so data is ok")
    else: 
        print("something is wrong with your data")
        
    return xData, yData #xData= rainfall seq, yData = landslides, i.e. target variable 

## added on 21/2/24

def rainfallMatrix_4(maxDf, sumDf, cumDf, diffDf): 

    maxDfLen = len(maxDf)
    sumDfLen = len(sumDf)
    cumDfLen = len(cumDf)
    diffDfLen = len(diffDf)

    if maxDfLen != sumDfLen: 
        print("max df length doesn't match sum ")
    
    elif maxDfLen != cumDfLen: 
        print("max df length doesn't match cumulative")
    
    elif sumDfLen != cumDfLen: 
        print("sum df length doesn't match cumulative")
    
    elif sumDfLen != diffDfLen:
        print("sum df length doesn't match difference")

    elif maxDfLen != diffDfLen:
        print("max df length doesn't match difference")
    
    elif cumDfLen != diffDfLen:
        print("cumulative df length doesn't match difference")
    
    timeSeriesLength = len(maxDf.columns)

    mainMatrix = []
    occurrenceMatrix = []
    dayMatrix = []

    for i in np.arange(0, maxDfLen, 1):
        for j in np.arange(0, timeSeriesLength, 1): # note the format is [row,col]
            dayMatrix = [maxDf.iloc[i,j], sumDf.iloc[i,j], cumDf.iloc[i,j], diffDf.iloc[i,j]]
            occurrenceMatrix.append(dayMatrix)
            dayMatrix = []
        mainMatrix.append(occurrenceMatrix)
        occurrenceMatrix = []
    
    return np.array(mainMatrix, dtype=np.float64)