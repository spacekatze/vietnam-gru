# # adapted from ashok's script ## 
import tensorflow as tf
import wandb
from wandb.keras import WandbMetricsLogger
wandb.init(config={"bs": 12},project='msc-Thesis')

def trainmodel(model,xdata,ydata,args, xtest, ytest):
    print("Fit model on training data")
    NUMBER_EPOCHS = args['nepoch']
    filepath=args['ckpt']
    BATCH_SIZE=args['batchsize']
    validation_split=args['valsplit']
    
    # model_checkpoint_callback=tf.keras.callbacks.ModelCheckpoint(
    #     filepath,
    #     monitor="val_loss",
    #     mode="min",
    #     verbose=1,
    #     save_best_only=True,
    #     save_weights_only=False,
    #     # monitor="val_auc",
    #     # mode="max",
    #     save_freq="epoch",
    #     options=None
    # )
    
    model_checkpoint_callback=tf.keras.callbacks.ModelCheckpoint(
        filepath,
        monitor="val_loss",
        verbose=2,
        save_best_only=True,
        save_weights_only=False,
        mode="min",
        save_freq="epoch",
        options=None
    )
    
    # early_stopping_callback = tf.keras.callbacks.EarlyStopping(
    #     monitor="val_auc", 
    #     mode='max',
    #     patience=30,
    #     verbose=1, 
    #     restore_best_weights=True
    # )
    
    hist = model.fit(x=xdata,
                     y=ydata,
                     epochs=NUMBER_EPOCHS,
                     batch_size=BATCH_SIZE,
                     validation_data=(xtest, ytest),
                     verbose=2, 
                     callbacks=[model_checkpoint_callback, WandbMetricsLogger()]
                     # callbacks=[model_checkpoint_callback,early_stopping_callback, WandbMetricsLogger()]
                    )
    return hist
