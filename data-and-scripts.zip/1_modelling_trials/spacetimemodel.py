from tensorflow.keras.layers import Input, GRU, Dense, Flatten, Embedding, Dropout, Concatenate, BatchNormalization
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.optimizers import SGD, Adam
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.metrics import Precision, Recall, Accuracy, AUC
from tensorflow.keras.optimizers.schedules import ExponentialDecay
import tensorflow as tf
from keras import backend as K

# tf.random.set_seed(42)

class spacetimemodel():
    def __init__(self,modelparam):
        # params related to 'time' component
        self.gru_depth=modelparam['gru_depth']
        self.gru_units=modelparam['gru_units']
        self.no_time_series_param=modelparam['no_time_series_param']
        self.time_series_length=modelparam['time_series_length']
        self.gru_activation=modelparam['gru_activation']
        
        # params related to 'env' component 
        self.no_env_param=modelparam['no_env_param']
        self.env_depth=modelparam['env_depth']
        self.env_units=modelparam['env_units']
        self.env_activation=modelparam['env_activation']

        # params related to 'combined' component
        self.comb_depth=modelparam['comb_depth']
        self.comb_units=modelparam['comb_units']
        self.comb_activation=modelparam['comb_activation']

        # initializers 
        self.kernel_initializer=modelparam['kernel_initializer']
        self.bias_initializer=modelparam['bias_initializer']
        self.dropout=modelparam['dropout']
        self.batch_normalization=modelparam['batch_normalization']
        self.env_dropout_ratio=modelparam['env_dropout_ratio']
        self.gru_dropout_ratio=modelparam['gru_dropout_ratio']
        self.comb_dropout_ratio=modelparam['comb_dropout_ratio']

        self.lr=modelparam['lr']
        self.decay_steps=modelparam['decay_steps']
        self.decay_rate=modelparam['decay_rate']

        self.loss='binary_crossentropy'
        self.opt=Adam
        self.metrics=[Precision(thresholds=0.5), Recall(thresholds=0.5), 'Accuracy', 'AUC']

    def space_time_model(self):  
        
        #prepare input vaiables
        in_stat=Input(shape=(self.no_env_param)) #static
        in_time=Input(shape=(self.time_series_length, 
                             self.no_time_series_param)) #timeseries

        # process timeseries 
        '''
        #ASHOK:Comment this out to test for exploding gradients. update later if one GRU solves the issue
        x = GRU(units=self.gru_units, return_sequences=True, 
            activation=self.gru_activation, bias_initializer = self.bias_initializer, 
            kernel_initializer=self.kernel_initializer)(in_time) 
        if self.batch_normalization:
            x= BatchNormalization()(x)
        if self.dropout:
            x= Dropout(self.dropout_ratio)(x) 
        '''
        '''
        #ASHOK: first comment this out and test with only one GRU
        for i in range(self.gru_depth):
            x = GRU(units=self.gru_units, return_sequences=True, 
                    activation=self.gru_activation, bias_initializer = self.bias_initializer,
                    kernel_initializer=self.kernel_initializer)(x)#process timeseries
            if self.batch_normalization:
                x = BatchNormalization()(x)
            if self.dropout:
                x = Dropout(self.dropout_ratio)(x) 
        '''    
        x = GRU(units=self.gru_units, return_sequences=False, 
            activation=self.gru_activation, bias_initializer = self.bias_initializer, 
            kernel_initializer=self.kernel_initializer)(in_time) #ASHOK: (x) has been rplaced by in_time
        
        # ashok removed this dropout and normalization but let's add it back 
        if self.batch_normalization:
                x = BatchNormalization()(x)
        if self.dropout:
                x = Dropout(self.gru_dropout_ratio)(x) 

        # process env params 
        y = Dense(units=self.env_units, activation=self.gru_activation, bias_initializer=self.bias_initializer)(in_stat) #process static
        y = Dropout(self.env_dropout_ratio)(y)#process static

        for i in range(self.env_depth):
            y = Dense(units=self.env_units, activation=self.env_activation, bias_initializer=self.bias_initializer)(y)#process static
            if self.batch_normalization:
                y = BatchNormalization()(y)#process static
            if self.dropout: 
                y = Dropout(self.env_dropout_ratio)(y)

        #Concatenate here with timeseries
        z=Concatenate()([x, y])

        # processing combined 
        for i in range(self.comb_depth):
            z = Dense(units=self.comb_units, activation=self.comb_activation, bias_initializer=self.bias_initializer)(z)
            if self.batch_normalization:
                z = BatchNormalization()(z)
            if self.dropout: 
                z = Dropout(self.comb_dropout_ratio)(z)
            
        out = Dense(1,activation="sigmoid")(z)

        model = Model([in_stat,in_time], out)
        # model.compile(optimizer='adam',
        #             loss='binary_crossentropy',
        #             metrics=['accuracy'])

        return model

    def getOptimizer(self,):
        lr_schedule = ExponentialDecay(initial_learning_rate=self.lr,decay_steps=self.decay_steps,decay_rate=self.decay_rate,staircase=True)
        # self.optimizer = SGD(learning_rate=lr_schedule)
        self.optimizer = Adam(learning_rate=lr_schedule)
    # def getf1score(self,y_true, y_pred):
    #     TP = tf.math.count_nonzero(y_pred * y_true)
    #     TN = tf.math.count_nonzero((y_pred - 1) * (y_true - 1))
    #     FP = tf.math.count_nonzero(y_pred * (y_true - 1))
    #     FN = tf.math.count_nonzero((y_pred - 1) * y_true)
    #     precision = TP / (TP + FP)
    #     recall = TP / (TP + FN)
    #     f1 = 2 * precision * recall / (precision + recall)
    #     return f1
    
    def recall_m(self,y_true, y_pred):
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
        recall = true_positives / (possible_positives + K.epsilon())
        return recall

    def precision_m(self,y_true, y_pred):
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
        precision = true_positives / (predicted_positives + K.epsilon())
        return precision

    def f1_m(self,y_true, y_pred):
        precision = self.precision_m(y_true, y_pred)
        recall = self.recall_m(y_true, y_pred)
        return 2*((precision*recall)/(precision+recall+K.epsilon()))
    def preparemodel(self,):
        model = self.space_time_model()
        self.getOptimizer()
        model.compile(optimizer=self.optimizer, loss=self.loss, metrics=[self.metrics,self.f1_m])
        # model.compile(optimizer=self.optimizer, loss=self.loss, metrics=[self.metrics,self.f1_m])
        return model 
